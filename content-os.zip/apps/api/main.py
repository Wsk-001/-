from __future__ import annotations

import os
import json
from typing import Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import init_db
from api import auth, tasks, pipelines, articles, prompts, sources, llm_configs, templates, ws

app = FastAPI(
    title="Content OS API",
    description="Content OS 后端 API 服务",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(tasks.router)
app.include_router(pipelines.router)
app.include_router(articles.router)
app.include_router(prompts.router)
app.include_router(sources.router)
app.include_router(llm_configs.router)
app.include_router(templates.router)
app.include_router(ws.router)


@app.on_event("startup")
async def startup_event():
    await init_db()


@app.get("/health")
async def health_check():
    return {"status": "ok", "service": "content-os-api"}


# Serve the standalone HTML dashboard (no Node.js needed)
_WEB_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "web", "dist")

@app.get("/")
async def serve_dashboard():
    html_path = os.path.join(_WEB_DIR, "index.html")
    if os.path.exists(html_path):
        return FileResponse(html_path, media_type="text/html")
    return {"message": "Content OS API is running. Dashboard not found at " + html_path}


if os.path.isdir(_WEB_DIR):
    app.mount("/static", StaticFiles(directory=_WEB_DIR), name="static")


@app.websocket("/api/ws/tasks/{task_id}")
async def websocket_task_events(websocket: WebSocket, task_id: str):
    await websocket.accept()

    try:
        import redis.asyncio as aioredis
    except ImportError:
        await websocket.send_text(json.dumps({"event": "info", "data": {"message": "Redis not available, real-time updates disabled"}}))
        await websocket.close()
        return

    from core.config import settings

    redis_client = aioredis.from_url(settings.REDIS_URL, decode_responses=True)
    pubsub = redis_client.pubsub()
    channel = f"task:{task_id}"
    await pubsub.subscribe(channel)

    try:
        async for message in pubsub.listen():
            if message is None:
                continue
            msg_type = message.get("type")
            if msg_type != "message":
                continue
            data = message.get("data")
            if data is None:
                continue
            await websocket.send_text(data if isinstance(data, str) else data.decode("utf-8"))
    except WebSocketDisconnect:
        pass
    finally:
        await pubsub.unsubscribe(channel)
        await pubsub.close()
        await redis_client.close()
